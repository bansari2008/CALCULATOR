
/*
    ALL-IN-ONE CALCULATOR - MODERN LIGHT EDITION

    Language : C
    GUI      : Windows Win32 API
    Compiler : GCC / MSYS2 UCRT64

    Modules:
    1. Normal Calculator
    2. Scientific Calculator
    3. Number System Converter
    4. Measurement Converter
    5. Calculation History

    No graphics.h. No C++.
*/

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <errno.h>

/* -------------------- CONTROL IDs -------------------- */

#define ID_CATEGORY       101
#define ID_OPERATION      102
#define ID_INPUT1         103
#define ID_INPUT2         104
#define ID_CALCULATE      105
#define ID_RESULT         106
#define ID_HISTORY        107
#define ID_CLEAR_HISTORY  108
#define ID_INPUT1_LABEL   109
#define ID_INPUT2_LABEL   110

#define APP_WIDTH  1100
#define APP_HEIGHT 720

/* -------------------- GLOBAL VARIABLES -------------------- */

HWND categoryBox;
HWND operationBox;
HWND input1;
HWND input2;
HWND resultLabel;
HWND historyList;
HWND input1Label;
HWND input2Label;

HFONT normalFont;
HFONT titleFont;
HFONT headingFont;

HBRUSH backgroundBrush;
HBRUSH whiteBrush;
HBRUSH inputBrush;
HBRUSH resultBrush;

char historyPath[MAX_PATH];

/* Light dashboard colors */
#define COLOR_BACKGROUND RGB(242, 246, 252)
#define COLOR_WHITE      RGB(255, 255, 255)
#define COLOR_BLUE       RGB(37, 99, 235)
#define COLOR_DARK       RGB(30, 41, 59)
#define COLOR_MUTED      RGB(100, 116, 139)
#define COLOR_INPUT      RGB(248, 250, 252)
#define COLOR_RESULT     RGB(239, 246, 255)
#define COLOR_BORDER     RGB(219, 228, 240)

/* -------------------- OPERATION LISTS -------------------- */

const char *normalOperations[] = {
    "Addition",
    "Subtraction",
    "Multiplication",
    "Division",
    "Modulus",
    "Square",
    "Square Root",
    "Power",
    "Percentage",
    "Sine (Degrees)",
    "Cosine (Degrees)",
    "Tangent (Degrees)",
    "Logarithm (Base 10)",
    "Pi"
};

const char *numberOperations[] = {
    "Binary to Decimal",
    "Octal to Decimal",
    "Hexadecimal to Decimal",
    "Decimal to Binary",
    "Decimal to Octal",
    "Decimal to Hexadecimal"
};

const char *measurementOperations[] = {
    /* Length */
    "Millimeter to Centimeter",
    "Millimeter to Meter",
    "Millimeter to Kilometer",
    "Centimeter to Millimeter",
    "Centimeter to Meter",
    "Centimeter to Kilometer",
    "Meter to Millimeter",
    "Meter to Centimeter",
    "Meter to Kilometer",
    "Kilometer to Millimeter",
    "Kilometer to Centimeter",
    "Kilometer to Meter",

    /* Weight */
    "Milligram to Gram",
    "Milligram to Kilogram",
    "Milligram to Tonne",
    "Gram to Milligram",
    "Gram to Kilogram",
    "Gram to Tonne",
    "Kilogram to Milligram",
    "Kilogram to Gram",
    "Kilogram to Tonne",
    "Tonne to Milligram",
    "Tonne to Gram",
    "Tonne to Kilogram",

    /* Temperature */
    "Celsius to Fahrenheit",
    "Celsius to Kelvin",
    "Fahrenheit to Celsius",
    "Fahrenheit to Kelvin",
    "Kelvin to Celsius",
    "Kelvin to Fahrenheit",

    /* Area */
    "Square Meter to Square Kilometer",
    "Square Meter to Hectare",
    "Square Kilometer to Square Meter",
    "Square Kilometer to Hectare",
    "Hectare to Square Meter",
    "Hectare to Square Kilometer",

    /* Volume */
    "Milliliter to Liter",
    "Milliliter to Cubic Meter",
    "Liter to Milliliter",
    "Liter to Cubic Meter",
    "Cubic Meter to Milliliter",
    "Cubic Meter to Liter"
};

/* -------------------- GUI HELPERS -------------------- */

HWND CreateControl(
    HWND parent,
    const char *className,
    const char *text,
    DWORD style,
    int x,
    int y,
    int width,
    int height,
    int id
) {
    HWND control = CreateWindowExA(
        0,
        className,
        text,
        WS_CHILD | WS_VISIBLE | style,
        x, y, width, height,
        parent,
        (HMENU)(INT_PTR)id,
        GetModuleHandleA(NULL),
        NULL
    );

    if (control && normalFont) {
        SendMessageA(
            control,
            WM_SETFONT,
            (WPARAM)normalFont,
            TRUE
        );
    }

    return control;
}

void AddItems(HWND combo, const char **items, int count) {
    int i;

    SendMessageA(combo, CB_RESETCONTENT, 0, 0);

    for (i = 0; i < count; i++) {
        SendMessageA(
            combo,
            CB_ADDSTRING,
            0,
            (LPARAM)items[i]
        );
    }

    SendMessageA(combo, CB_SETCURSEL, 0, 0);
}

int GetSelection(HWND combo) {
    return (int)SendMessageA(combo, CB_GETCURSEL, 0, 0);
}

void SetResultText(const char *message) {
    SetWindowTextA(resultLabel, message);
}

void ShowError(const char *message) {
    SetResultText(message);
}

/* -------------------- HISTORY -------------------- */

void InitHistoryPath(void) {
    DWORD length = GetModuleFileNameA(
        NULL,
        historyPath,
        MAX_PATH
    );

    if (length == 0 || length >= MAX_PATH) {
        strcpy(historyPath, "history.txt");
        return;
    }

    char *slash = strrchr(historyPath, '\\');

    if (slash) {
        strcpy(slash + 1, "history.txt");
    } else {
        strcpy(historyPath, "history.txt");
    }
}

void AddHistory(const char *entry) {
    FILE *file = fopen(historyPath, "a");

    if (file) {
        fprintf(file, "%s\n", entry);
        fclose(file);
    }

    if (historyList) {
        SendMessageA(
            historyList,
            LB_ADDSTRING,
            0,
            (LPARAM)entry
        );
    }
}

void LoadHistory(void) {
    FILE *file = fopen(historyPath, "r");
    char line[500];

    if (!file) {
        return;
    }

    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = '\0';

        if (historyList) {
            SendMessageA(
                historyList,
                LB_ADDSTRING,
                0,
                (LPARAM)line
            );
        }
    }

    fclose(file);
}

void ClearHistory(void) {
    FILE *file = fopen(historyPath, "w");

    if (file) {
        fclose(file);
    }

    if (historyList) {
        SendMessageA(
            historyList,
            LB_RESETCONTENT,
            0,
            0
        );
    }
}

/* -------------------- INPUT VALIDATION -------------------- */

int ReadDouble(HWND control, double *value) {
    char buffer[128];
    char *end;

    GetWindowTextA(control, buffer, sizeof(buffer));

    if (buffer[0] == '\0') {
        return 0;
    }

    errno = 0;
    *value = strtod(buffer, &end);

    if (end == buffer || errno == ERANGE) {
        return 0;
    }

    while (*end == ' ' || *end == '\t') {
        end++;
    }

    if (*end != '\0' || !isfinite(*value)) {
        return 0;
    }

    return 1;
}

/* -------------------- NUMBER SYSTEM -------------------- */

int ParseUnsigned(
    const char *text,
    int base,
    unsigned long long *value
) {
    char *end;

    if (text[0] == '\0' || text[0] == '-') {
        return 0;
    }

    errno = 0;
    *value = strtoull(text, &end, base);

    if (end == text || errno == ERANGE) {
        return 0;
    }

    while (*end == ' ' || *end == '\t') {
        end++;
    }

    return (*end == '\0');
}

void ConvertBase(
    unsigned long long number,
    int base,
    char *output
) {
    char temporary[70];
    const char digits[] = "0123456789ABCDEF";
    int index = 0;
    int position = 0;

    if (number == 0) {
        strcpy(output, "0");
        return;
    }

    while (number > 0) {
        temporary[index++] = digits[number % base];
        number /= base;
    }

    while (index > 0) {
        output[position++] = temporary[--index];
    }

    output[position] = '\0';
}

void CalculateNumberSystem(int operation) {
    char text[128];
    char output[300];
    unsigned long long number;
    int base;

    GetWindowTextA(input1, text, sizeof(text));

    if (operation < 0 || operation > 5) {
        ShowError("Invalid number system operation.");
        return;
    }

    if (operation == 0) {
        base = 2;
    } else if (operation == 1) {
        base = 8;
    } else if (operation == 2) {
        base = 16;
    } else {
        base = 10;
    }

    if (!ParseUnsigned(text, base, &number)) {
        ShowError("Invalid number. Check the selected base.");
        return;
    }

    switch (operation) {
        case 0:
        case 1:
        case 2:
            snprintf(
                output,
                sizeof(output),
                "Decimal: %llu",
                number
            );
            break;

        case 3:
            ConvertBase(number, 2, output);
            break;

        case 4:
            ConvertBase(number, 8, output);
            break;

        case 5:
            ConvertBase(number, 16, output);
            break;

        default:
            return;
    }

    SetResultText(output);
    AddHistory(output);
}

/* -------------------- NORMAL / SCIENTIFIC -------------------- */

void CalculateNormal(int operation) {
    double a = 0.0;
    double b = 0.0;
    double answer = 0.0;

    int needsFirst = (operation != 13);

    int needsSecond =
        (operation >= 0 && operation <= 4) ||
        operation == 7 ||
        operation == 8;

    if (needsFirst && !ReadDouble(input1, &a)) {
        ShowError("Enter a valid first number.");
        return;
    }

    if (needsSecond && !ReadDouble(input2, &b)) {
        ShowError("Enter a valid second number.");
        return;
    }

    switch (operation) {
        case 0:
            answer = a + b;
            break;

        case 1:
            answer = a - b;
            break;

        case 2:
            answer = a * b;
            break;

        case 3:
            if (b == 0.0) {
                ShowError("Cannot divide by zero.");
                return;
            }
            answer = a / b;
            break;

        case 4:
            if (b == 0.0) {
                ShowError("Cannot use modulus by zero.");
                return;
            }

            if (floor(a) != a || floor(b) != b) {
                ShowError("Modulus requires whole numbers.");
                return;
            }

            answer = fmod(a, b);
            break;

        case 5:
            answer = a * a;
            break;

        case 6:
            if (a < 0.0) {
                ShowError("Square root needs a non-negative number.");
                return;
            }
            answer = sqrt(a);
            break;

        case 7:
            answer = pow(a, b);
            break;

        case 8:
            answer = (a * b) / 100.0;
            break;

        case 9:
            answer = sin(a * 3.14159265358979323846 / 180.0);
            break;

        case 10:
            answer = cos(a * 3.14159265358979323846 / 180.0);
            break;

        case 11:
            if (fabs(cos(a * 3.14159265358979323846 / 180.0)) < 1e-12) {
                ShowError("Tangent is undefined at this angle.");
                return;
            }
            answer = tan(a * 3.14159265358979323846 / 180.0);
            break;

        case 12:
            if (a <= 0.0) {
                ShowError("Logarithm needs a positive number.");
                return;
            }
            answer = log10(a);
            break;

        case 13:
            answer = 3.14159265358979323846;
            break;

        default:
            ShowError("Invalid operation.");
            return;
    }

    if (!isfinite(answer)) {
        ShowError("Result is outside the valid range.");
        return;
    }

    char output[300];

    snprintf(
        output,
        sizeof(output),
        "Result: %.12g",
        answer
    );

    SetResultText(output);
    AddHistory(output);
}

/* -------------------- MEASUREMENT CONVERTER -------------------- */

void CalculateMeasurement(int operation) {
    double value;
    double result = 0.0;
    char output[300];

    if (operation < 0 || operation >= 42) {
        ShowError("Invalid measurement operation.");
        return;
    }

    if (!ReadDouble(input1, &value)) {
        ShowError("Enter a valid measurement.");
        return;
    }

    /* LENGTH: mm, cm, m, km */
    if (operation < 12) {
        const double factor[] = {
            0.001, 0.01, 1.0, 1000.0
        };

        int relative = operation;
        int source = relative / 3;
        int targetSlot = relative % 3;
        int target = targetSlot;

        if (target >= source) {
            target++;
        }

        if (value < 0.0) {
            ShowError("Length cannot be negative.");
            return;
        }

        result = value * factor[source] / factor[target];
    }

    /* WEIGHT: mg, g, kg, tonne */
    else if (operation < 24) {
        const double factor[] = {
            0.000001, 0.001, 1.0, 1000.0
        };

        int relative = operation - 12;
        int source = relative / 3;
        int targetSlot = relative % 3;
        int target = targetSlot;

        if (target >= source) {
            target++;
        }

        if (value < 0.0) {
            ShowError("Weight cannot be negative.");
            return;
        }

        result = value * factor[source] / factor[target];
    }

    /* TEMPERATURE: C, F, K */
    else if (operation < 30) {
        int relative = operation - 24;
        int source = relative / 2;
        int targetSlot = relative % 2;
        int target = targetSlot;
        double celsius;

        if (target >= source) {
            target++;
        }

        if (source == 2 && value < 0.0) {
            ShowError("Kelvin cannot be below absolute zero.");
            return;
        }

        if (source == 0) {
            celsius = value;
        } else if (source == 1) {
            celsius = (value - 32.0) * 5.0 / 9.0;
        } else {
            celsius = value - 273.15;
        }

        if (target == 0) {
            result = celsius;
        } else if (target == 1) {
            result = celsius * 9.0 / 5.0 + 32.0;
        } else {
            result = celsius + 273.15;
        }
    }

    /* AREA: m2, km2, hectare */
    else if (operation < 36) {
        const double factor[] = {
            1.0, 1000000.0, 10000.0
        };

        int relative = operation - 30;
        int source = relative / 2;
        int targetSlot = relative % 2;
        int target = targetSlot;

        if (target >= source) {
            target++;
        }

        if (value < 0.0) {
            ShowError("Area cannot be negative.");
            return;
        }

        result = value * factor[source] / factor[target];
    }

    /* VOLUME: ml, litre, cubic metre */
    else {
        const double factor[] = {
            0.000001, 0.001, 1.0
        };

        int relative = operation - 36;
        int source = relative / 2;
        int targetSlot = relative % 2;
        int target = targetSlot;

        if (target >= source) {
            target++;
        }

        if (value < 0.0) {
            ShowError("Volume cannot be negative.");
            return;
        }

        result = value * factor[source] / factor[target];
    }

    if (!isfinite(result)) {
        ShowError("Conversion result is outside the valid range.");
        return;
    }

    snprintf(
        output,
        sizeof(output),
        "Converted Result: %.12g",
        result
    );

    SetResultText(output);
    AddHistory(output);
}

/* -------------------- MAIN CALCULATE -------------------- */

void Calculate(void) {
    int mode = GetSelection(categoryBox);
    int operation = GetSelection(operationBox);

    if (operation < 0) {
        ShowError("Select an operation first.");
        return;
    }

    if (mode == 0) {
        CalculateNormal(operation);
    } else if (mode == 1) {
        CalculateNumberSystem(operation);
    } else if (mode == 2) {
        CalculateMeasurement(operation);
    } else {
        ShowError("Select a calculator type.");
    }
}

/* -------------------- UPDATE MODE -------------------- */

void UpdateMode(void) {
    int mode = GetSelection(categoryBox);

    if (mode == 0) {
        AddItems(operationBox, normalOperations, 14);

        ShowWindow(input2, SW_SHOW);
        ShowWindow(input2Label, SW_SHOW);
    } else if (mode == 1) {
        AddItems(operationBox, numberOperations, 6);

        ShowWindow(input2, SW_HIDE);
        ShowWindow(input2Label, SW_HIDE);
    } else if (mode == 2) {
        AddItems(operationBox, measurementOperations, 42);

        ShowWindow(input2, SW_HIDE);
        ShowWindow(input2Label, SW_HIDE);
    }

    SetWindowTextA(input1, "");
    SetWindowTextA(input2, "");

    SetResultText("Your result will appear here.");
}

/* -------------------- CUSTOM DASHBOARD DRAWING -------------------- */

void DrawRoundRect(
    HDC hdc,
    int x,
    int y,
    int width,
    int height,
    COLORREF color,
    int radius
) {
    HBRUSH brush = CreateSolidBrush(color);
    HPEN pen = CreatePen(PS_SOLID, 1, color);

    HGDIOBJ oldBrush = SelectObject(hdc, brush);
    HGDIOBJ oldPen = SelectObject(hdc, pen);

    RoundRect(
        hdc,
        x, y,
        x + width, y + height,
        radius, radius
    );

    SelectObject(hdc, oldBrush);
    SelectObject(hdc, oldPen);

    DeleteObject(brush);
    DeleteObject(pen);
}

void DrawDashboard(HDC hdc) {
    /* Main white dashboard cards */
    DrawRoundRect(
        hdc, 25, 95, 650, 555,
        COLOR_WHITE, 18
    );

    DrawRoundRect(
        hdc, 700, 95, 365, 555,
        COLOR_WHITE, 18
    );
}

/* -------------------- CUSTOM BUTTON DRAWING -------------------- */

void DrawButton(const DRAWITEMSTRUCT *item) {
    HDC hdc = item->hDC;
    RECT rect = item->rcItem;

    COLORREF buttonColor = COLOR_BLUE;
    COLORREF textColorButton = COLOR_WHITE;

    if (item->CtlID == ID_CLEAR_HISTORY) {
        buttonColor = RGB(239, 68, 68);
    }

    if (item->itemState & ODS_DISABLED) {
        buttonColor = RGB(148, 163, 184);
    }

    int width = rect.right - rect.left;
    int height = rect.bottom - rect.top;

    HBRUSH brush = CreateSolidBrush(buttonColor);
    HPEN pen = CreatePen(PS_SOLID, 1, buttonColor);

    HGDIOBJ oldBrush = SelectObject(hdc, brush);
    HGDIOBJ oldPen = SelectObject(hdc, pen);

    RoundRect(
        hdc,
        rect.left + 2,
        rect.top + 2,
        rect.left + width - 2,
        rect.top + height - 2,
        12, 12
    );

    SelectObject(hdc, oldBrush);
    SelectObject(hdc, oldPen);

    DeleteObject(brush);
    DeleteObject(pen);

    char text[128] = "";

    GetWindowTextA(
        item->hwndItem,
        text,
        sizeof(text)
    );

    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, textColorButton);

    HFONT font = CreateFontA(
        17, 0, 0, 0,
        FW_BOLD,
        FALSE, FALSE, FALSE,
        DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS,
        CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY,
        DEFAULT_PITCH | FF_DONTCARE,
        "Segoe UI"
    );

    HGDIOBJ oldFont = SelectObject(hdc, font);

    DrawTextA(
        hdc,
        text,
        -1,
        &rect,
        DT_CENTER | DT_VCENTER | DT_SINGLELINE
    );

    SelectObject(hdc, oldFont);
    DeleteObject(font);
}

/* -------------------- WINDOW PROCEDURE -------------------- */

LRESULT CALLBACK WindowProcedure(
    HWND hwnd,
    UINT message,
    WPARAM wParam,
    LPARAM lParam
) {
    switch (message) {

        case WM_CREATE: {
            HWND title;
            HWND subtitle;
            HWND calculatorHeading;
            HWND historyHeading;
            HWND categoryLabel;
            HWND operationLabel;
            HWND calculateButton;
            HWND clearButton;

            title = CreateControl(
                hwnd, "STATIC",
                "ALL-IN-ONE CALCULATOR",
                SS_LEFT,
                35, 20, 600, 40,
                0
            );

            SendMessageA(
                title, WM_SETFONT,
                (WPARAM)titleFont, TRUE
            );

            subtitle = CreateControl(
                hwnd, "STATIC",
                "Smart calculations. Simple experience.",
                SS_LEFT,
                38, 60, 600, 25,
                0
            );

            calculatorHeading = CreateControl(
                hwnd, "STATIC",
                "Calculator Workspace",
                SS_LEFT,
                50, 112, 500, 30,
                0
            );

            SendMessageA(
                calculatorHeading, WM_SETFONT,
                (WPARAM)headingFont, TRUE
            );

            historyHeading = CreateControl(
                hwnd, "STATIC",
                "Calculation History",
                SS_LEFT,
                725, 112, 300, 30,
                0
            );

            SendMessageA(
                historyHeading, WM_SETFONT,
                (WPARAM)headingFont, TRUE
            );

            categoryLabel = CreateControl(
                hwnd, "STATIC",
                "Calculator Type",
                SS_LEFT,
                55, 165, 250, 25,
                0
            );

            categoryBox = CreateControl(
                hwnd, "COMBOBOX", "",
                CBS_DROPDOWNLIST | WS_VSCROLL,
                55, 193, 580, 250,
                ID_CATEGORY
            );

            operationLabel = CreateControl(
                hwnd, "STATIC",
                "Select Operation",
                SS_LEFT,
                55, 250, 250, 25,
                0
            );

            operationBox = CreateControl(
                hwnd, "COMBOBOX", "",
                CBS_DROPDOWNLIST | WS_VSCROLL,
                55, 278, 580, 250,
                ID_OPERATION
            );

            input1Label = CreateControl(
                hwnd, "STATIC",
                "First Value",
                SS_LEFT,
                55, 335, 250, 25,
                ID_INPUT1_LABEL
            );

            input1 = CreateControl(
                hwnd, "EDIT", "",
                ES_AUTOHSCROLL | WS_BORDER,
                55, 363, 580, 38,
                ID_INPUT1
            );

            input2Label = CreateControl(
                hwnd, "STATIC",
                "Second Value (if required)",
                SS_LEFT,
                55, 415, 300, 25,
                ID_INPUT2_LABEL
            );

            input2 = CreateControl(
                hwnd, "EDIT", "",
                ES_AUTOHSCROLL | WS_BORDER,
                55, 443, 580, 38,
                ID_INPUT2
            );

            calculateButton = CreateControl(
                hwnd, "BUTTON",
                "CALCULATE",
                BS_OWNERDRAW,
                55, 500, 580, 48,
                ID_CALCULATE
            );

            resultLabel = CreateControl(
                hwnd, "STATIC",
                "Your result will appear here.",
                SS_LEFT | SS_CENTERIMAGE,
                55, 565, 580, 60,
                ID_RESULT
            );

            historyList = CreateControl(
                hwnd, "LISTBOX", "",
                WS_VSCROLL | LBS_NOTIFY,
                725, 155, 315, 420,
                ID_HISTORY
            );

            clearButton = CreateControl(
                hwnd, "BUTTON",
                "CLEAR HISTORY",
                BS_OWNERDRAW,
                725, 590, 315, 45,
                ID_CLEAR_HISTORY
            );

            (void)subtitle;

            /* Add category options */
            const char *categories[] = {
                "Normal / Scientific Calculator",
                "Number System Calculator",
                "Measurement Calculator"
            };

            AddItems(categoryBox, categories, 3);

            UpdateMode();
            LoadHistory();

            return 0;
        }

        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);

            DrawDashboard(hdc);

            EndPaint(hwnd, &ps);
            return 0;
        }

        case WM_DRAWITEM: {
            DRAWITEMSTRUCT *item =
                (DRAWITEMSTRUCT *)lParam;

            if (item->CtlID == ID_CALCULATE ||
                item->CtlID == ID_CLEAR_HISTORY) {
                DrawButton(item);
                return TRUE;
            }

            break;
        }

        case WM_COMMAND: {
            int id = LOWORD(wParam);
            int event = HIWORD(wParam);

            if (id == ID_CATEGORY && event == CBN_SELCHANGE) {
                UpdateMode();
                return 0;
            }

            if (id == ID_CALCULATE && event == BN_CLICKED) {
                Calculate();
                return 0;
            }

            if (id == ID_CLEAR_HISTORY && event == BN_CLICKED) {
                ClearHistory();

                MessageBoxA(
                    hwnd,
                    "Calculation history cleared.",
                    "History",
                    MB_OK | MB_ICONINFORMATION
                );

                return 0;
            }

            return 0;
        }

        case WM_CTLCOLORSTATIC: {
            HDC hdc = (HDC)wParam;
            HWND control = (HWND)lParam;

            SetTextColor(hdc, COLOR_DARK);
            SetBkMode(hdc, TRANSPARENT);

            if (control == resultLabel) {
                SetTextColor(hdc, COLOR_BLUE);
                SetBkColor(hdc, COLOR_RESULT);
                return (LRESULT)resultBrush;
            }

            return (LRESULT)whiteBrush;
        }

        case WM_CTLCOLOREDIT:
        case WM_CTLCOLORLISTBOX: {
            HDC hdc = (HDC)wParam;

            SetTextColor(hdc, COLOR_DARK);
            SetBkColor(hdc, COLOR_INPUT);

            return (LRESULT)inputBrush;
        }

        case WM_DESTROY:
            if (normalFont) DeleteObject(normalFont);
            if (titleFont) DeleteObject(titleFont);
            if (headingFont) DeleteObject(headingFont);

            if (backgroundBrush) DeleteObject(backgroundBrush);
            if (whiteBrush) DeleteObject(whiteBrush);
            if (inputBrush) DeleteObject(inputBrush);
            if (resultBrush) DeleteObject(resultBrush);

            PostQuitMessage(0);
            return 0;
    }

    return DefWindowProcA(
        hwnd,
        message,
        wParam,
        lParam
    );
}

/* -------------------- APPLICATION ENTRY POINT -------------------- */

int WINAPI WinMain(
    HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPSTR lpCmdLine,
    int nCmdShow
) {
    (void)hPrevInstance;
    (void)lpCmdLine;

    WNDCLASSA wc = {0};

    wc.lpfnWndProc = WindowProcedure;
    wc.hInstance = hInstance;
    wc.lpszClassName = "ModernAllInOneCalculator";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);

    backgroundBrush = CreateSolidBrush(COLOR_BACKGROUND);
    whiteBrush = CreateSolidBrush(COLOR_WHITE);
    inputBrush = CreateSolidBrush(COLOR_INPUT);
    resultBrush = CreateSolidBrush(COLOR_RESULT);

    wc.hbrBackground = backgroundBrush;

    normalFont = CreateFontA(
        17, 0, 0, 0,
        FW_NORMAL,
        FALSE, FALSE, FALSE,
        DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS,
        CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY,
        DEFAULT_PITCH | FF_DONTCARE,
        "Segoe UI"
    );

    titleFont = CreateFontA(
        29, 0, 0, 0,
        FW_BOLD,
        FALSE, FALSE, FALSE,
        DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS,
        CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY,
        DEFAULT_PITCH | FF_DONTCARE,
        "Segoe UI"
    );

    headingFont = CreateFontA(
        21, 0, 0, 0,
        FW_BOLD,
        FALSE, FALSE, FALSE,
        DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS,
        CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY,
        DEFAULT_PITCH | FF_DONTCARE,
        "Segoe UI"
    );

    if (!RegisterClassA(&wc)) {
        MessageBoxA(
            NULL,
            "Window registration failed.",
            "Application Error",
            MB_OK | MB_ICONERROR
        );
        return 1;
    }

    InitHistoryPath();

    HWND hwnd = CreateWindowExA(
        0,
        "ModernAllInOneCalculator",
        "All-in-One Calculator - Modern Edition",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        APP_WIDTH,
        APP_HEIGHT,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    if (!hwnd) {
        MessageBoxA(
            NULL,
            "Could not create application window.",
            "Application Error",
            MB_OK | MB_ICONERROR
        );
        return 1;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG message;

    while (GetMessageA(&message, NULL, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageA(&message);
    }

    return (int)message.wParam;
}
