
/*
    PROJECT: ALL-IN-ONE CALCULATOR
    LANGUAGE: C
    GUI: Windows API (Win32)
    COMPILER: GCC (MSYS2 UCRT64)

    Features:
    1. Normal Calculator
    2. Scientific Calculator
    3. Number System Converter
    4. Measurement Converter
    5. Calculation History
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include <errno.h>

#define ID_CATEGORY       101
#define ID_OPERATION      102
#define ID_INPUT1         103
#define ID_INPUT2         104
#define ID_CALCULATE      105
#define ID_RESULT         106
#define ID_HISTORY        107
#define ID_CLEAR_HISTORY  108

#define HISTORY_FILE_NAME "history.txt"

#define APP_WIDTH  1050
#define APP_HEIGHT 650

/* Window controls */
HWND categoryBox;
HWND operationBox;
HWND input1;
HWND input2;
HWND resultLabel;
HWND historyList;
HWND input2Label;

/* Fonts and brushes */
HFONT appFont;
HFONT titleFont;

HBRUSH backgroundBrush;
HBRUSH inputBrush;
HBRUSH resultBrush;

COLORREF textColor = RGB(240, 245, 255);

/* History file path */
char historyPath[MAX_PATH];

/* Calculator operations */
const char *normalOperations[] = {
    "Addition",
    "Subtraction",
    "Multiplication",
    "Division",
    "Modulus",
    "Square",
    "Square Root",
    "Power",
    "Percentage",
    "Sine (Degrees)",
    "Cosine (Degrees)",
    "Tangent (Degrees)",
    "Logarithm (Base 10)",
    "Pi"
};

const char *numberOperations[] = {
    "Binary to Decimal",
    "Octal to Decimal",
    "Hexadecimal to Decimal",
    "Decimal to Binary",
    "Decimal to Octal",
    "Decimal to Hexadecimal"
};

const char *measurementOperations[] = {
    /* Length */
    "Millimeter to Centimeter",
    "Millimeter to Meter",
    "Millimeter to Kilometer",
    "Centimeter to Millimeter",
    "Centimeter to Meter",
    "Centimeter to Kilometer",
    "Meter to Millimeter",
    "Meter to Centimeter",
    "Meter to Kilometer",
    "Kilometer to Millimeter",
    "Kilometer to Centimeter",
    "Kilometer to Meter",

    /* Weight */
    "Milligram to Gram",
    "Milligram to Kilogram",
    "Milligram to Tonne",
    "Gram to Milligram",
    "Gram to Kilogram",
    "Gram to Tonne",
    "Kilogram to Milligram",
    "Kilogram to Gram",
    "Kilogram to Tonne",
    "Tonne to Milligram",
    "Tonne to Gram",
    "Tonne to Kilogram",

    /* Temperature */
    "Celsius to Fahrenheit",
    "Celsius to Kelvin",
    "Fahrenheit to Celsius",
    "Fahrenheit to Kelvin",
    "Kelvin to Celsius",
    "Kelvin to Fahrenheit",

    /* Area */
    "Square Meter to Square Kilometer",
    "Square Meter to Hectare",
    "Square Kilometer to Square Meter",
    "Square Kilometer to Hectare",
    "Hectare to Square Meter",
    "Hectare to Square Kilometer",

    /* Volume */
    "Milliliter to Liter",
    "Milliliter to Cubic Meter",
    "Liter to Milliliter",
    "Liter to Cubic Meter",
    "Cubic Meter to Milliliter",
    "Cubic Meter to Liter"
};

/* ---------------------------------------------------------
   BASIC GUI FUNCTIONS
--------------------------------------------------------- */

void CreateControl(
    HWND parent,
    const char *className,
    const char *text,
    DWORD style,
    int x,
    int y,
    int width,
    int height,
    int id
) {
    HWND control = CreateWindowA(
        className,
        text,
        WS_CHILD | WS_VISIBLE | style,
        x, y, width, height,
        parent,
        (HMENU)(INT_PTR)id,
        GetModuleHandleA(NULL),
        NULL
    );

    if (control && appFont) {
        SendMessageA(
            control,
            WM_SETFONT,
            (WPARAM)appFont,
            TRUE
        );
    }
}

void AddItems(HWND combo, const char **items, int count) {
    int i;

    SendMessageA(combo, CB_RESETCONTENT, 0, 0);

    for (i = 0; i < count; i++) {
        SendMessageA(
            combo,
            CB_ADDSTRING,
            0,
            (LPARAM)items[i]
        );
    }

    SendMessageA(combo, CB_SETCURSEL, 0, 0);
}

int GetSelection(HWND combo) {
    return (int)SendMessageA(combo, CB_GETCURSEL, 0, 0);
}

void SetResultText(const char *message) {
    SetWindowTextA(resultLabel, message);
}

void ShowError(const char *message) {
    SetResultText(message);
}

/* ---------------------------------------------------------
   HISTORY FUNCTIONS
--------------------------------------------------------- */

void InitHistoryPath(void) {
    DWORD length = GetModuleFileNameA(
        NULL,
        historyPath,
        MAX_PATH
    );

    if (length == 0 || length >= MAX_PATH) {
        strcpy(historyPath, HISTORY_FILE_NAME);
        return;
    }

    char *slash = strrchr(historyPath, '\\');

    if (slash != NULL) {
        strcpy(slash + 1, HISTORY_FILE_NAME);
    } else {
        strcpy(historyPath, HISTORY_FILE_NAME);
    }
}

void AddHistory(const char *entry) {
    FILE *file = fopen(historyPath, "a");

    if (file != NULL) {
        fprintf(file, "%s\n", entry);
        fclose(file);
    }

    if (historyList != NULL) {
        SendMessageA(
            historyList,
            LB_ADDSTRING,
            0,
            (LPARAM)entry
        );
    }
}

void LoadHistory(void) {
    FILE *file = fopen(historyPath, "r");
    char line[500];

    if (file == NULL) {
        return;
    }

    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = '\0';

        if (historyList != NULL) {
            SendMessageA(
                historyList,
                LB_ADDSTRING,
                0,
                (LPARAM)line
            );
        }
    }

    fclose(file);
}

void ClearHistory(void) {
    FILE *file = fopen(historyPath, "w");

    if (file != NULL) {
        fclose(file);
    }

    if (historyList != NULL) {
        SendMessageA(
            historyList,
            LB_RESETCONTENT,
            0,
            0
        );
    }
}

/* ---------------------------------------------------------
   INPUT VALIDATION
--------------------------------------------------------- */

int ReadDouble(HWND control, double *value) {
    char buffer[128];
    char *end;

    GetWindowTextA(control, buffer, sizeof(buffer));

    if (buffer[0] == '\0') {
        return 0;
    }

    errno = 0;
    *value = strtod(buffer, &end);

    if (end == buffer || errno == ERANGE) {
        return 0;
    }

    while (*end == ' ' || *end == '\t') {
        end++;
    }

    if (*end != '\0' || !isfinite(*value)) {
        return 0;
    }

    return 1;
}

/* ---------------------------------------------------------
   NUMBER SYSTEM CONVERSION
--------------------------------------------------------- */

int ParseUnsigned(const char *text, int base, unsigned long long *value) {
    char *end;

    if (text[0] == '\0' || text[0] == '-') {
        return 0;
    }

    errno = 0;

    *value = strtoull(text, &end, base);

    if (end == text || errno == ERANGE) {
        return 0;
    }

    while (*end == ' ' || *end == '\t') {
        end++;
    }

    return (*end == '\0');
}

void ConvertBase(unsigned long long number, int base, char *output) {
    char temporary[70];
    const char digits[] = "0123456789ABCDEF";
    int index = 0;
    int position = 0;

    if (number == 0) {
        strcpy(output, "0");
        return;
    }

    while (number > 0) {
        temporary[index++] = digits[number % base];
        number /= base;
    }

    while (index > 0) {
        output[position++] = temporary[--index];
    }

    output[position] = '\0';
}

void CalculateNumberSystem(int operation) {
    char text[128];
    char output[300];
    unsigned long long number;
    int base = 10;

    GetWindowTextA(input1, text, sizeof(text));

    switch (operation) {
        case 0:
            base = 2;
            break;

        case 1:
            base = 8;
            break;

        case 2:
            base = 16;
            break;

        case 3:
        case 4:
        case 5:
            base = 10;
            break;

        default:
            ShowError("Invalid number system operation.");
            return;
    }

    if (!ParseUnsigned(text, base, &number)) {
        ShowError("Invalid number. Check the selected base.");
        return;
    }

    switch (operation) {
        case 0:
        case 1:
        case 2:
            snprintf(
                output,
                sizeof(output),
                "Decimal: %llu",
                number
            );
            break;

        case 3:
            ConvertBase(number, 2, output);
            break;

        case 4:
            ConvertBase(number, 8, output);
            break;

        case 5:
            ConvertBase(number, 16, output);
            break;

        default:
            return;
    }

    SetResultText(output);
    AddHistory(output);
}

/* ---------------------------------------------------------
   NORMAL AND SCIENTIFIC CALCULATOR
--------------------------------------------------------- */

void CalculateNormal(int operation) {
    double a = 0.0;
    double b = 0.0;
    double answer = 0.0;

    int needsFirst = operation != 13;
    int needsSecond = (
        operation >= 0 && operation <= 4
    ) || operation == 7 || operation == 8;

    if (needsFirst && !ReadDouble(input1, &a)) {
        ShowError("Please enter a valid first number.");
        return;
    }

    if (needsSecond && !ReadDouble(input2, &b)) {
        ShowError("Please enter a valid second number.");
        return;
    }

    switch (operation) {
        case 0:
            answer = a + b;
            break;

        case 1:
            answer = a - b;
            break;

        case 2:
            answer = a * b;
            break;

        case 3:
            if (b == 0.0) {
                ShowError("Cannot divide by zero.");
                return;
            }
            answer = a / b;
            break;

        case 4:
            if (b == 0.0) {
                ShowError("Cannot calculate modulus by zero.");
                return;
            }

            if (floor(a) != a || floor(b) != b) {
                ShowError("Modulus requires whole numbers.");
                return;
            }

            answer = fmod(a, b);
            break;

        case 5:
            answer = a * a;
            break;

        case 6:
            if (a < 0.0) {
                ShowError("Square root of a negative number is invalid.");
                return;
            }
            answer = sqrt(a);
            break;

        case 7:
            answer = pow(a, b);
            break;

        case 8:
            answer = (a * b) / 100.0;
            break;

        case 9:
            answer = sin(a * 3.14159265358979323846 / 180.0);
            break;

        case 10:
            answer = cos(a * 3.14159265358979323846 / 180.0);
            break;

        case 11:
            if (fabs(cos(a * 3.14159265358979323846 / 180.0)) < 1e-12) {
                ShowError("Tangent is undefined at this angle.");
                return;
            }

            answer = tan(a * 3.14159265358979323846 / 180.0);
            break;

        case 12:
            if (a <= 0.0) {
                ShowError("Logarithm requires a positive number.");
                return;
            }

            answer = log10(a);
            break;

        case 13:
            answer = 3.14159265358979323846;
            break;

        default:
            ShowError("Invalid operation.");
            return;
    }

    if (!isfinite(answer)) {
        ShowError("Calculation result is outside the valid range.");
        return;
    }

    char output[300];

    snprintf(
        output,
        sizeof(output),
        "Result: %.12g",
        answer
    );

    SetResultText(output);
    AddHistory(output);
}

/* ---------------------------------------------------------
   MEASUREMENT CONVERTER
--------------------------------------------------------- */

void CalculateMeasurement(int operation) {
    double value;
    double result = 0.0;

    if (operation < 0 || operation >= 42) {
        ShowError("Invalid measurement operation.");
        return;
    }

    if (!ReadDouble(input1, &value)) {
        ShowError("Please enter a valid measurement.");
        return;
    }

    char output[300];

    /* LENGTH: millimeter, centimeter, meter, kilometer */
    if (operation >= 0 && operation < 12) {
        const double factor[] = {
            0.001, 0.01, 1.0, 1000.0
        };

        int relative = operation;
        int source = relative / 3;
        int targetSlot = relative % 3;
        int target = targetSlot;

        if (target >= source) {
            target++;
        }

        if (value < 0.0) {
            ShowError("Length cannot be negative.");
            return;
        }

        result = value * factor[source] / factor[target];
    }

    /* WEIGHT: milligram, gram, kilogram, tonne */
    else if (operation >= 12 && operation < 24) {
        const double factor[] = {
            0.000001, 0.001, 1.0, 1000.0
        };

        int relative = operation - 12;
        int source = relative / 3;
        int targetSlot = relative % 3;
        int target = targetSlot;

        if (target >= source) {
            target++;
        }

        if (value < 0.0) {
            ShowError("Weight cannot be negative.");
            return;
        }

        result = value * factor[source] / factor[target];
    }

    /* TEMPERATURE: Celsius, Fahrenheit, Kelvin */
    else if (operation >= 24 && operation < 30) {
        int relative = operation - 24;
        int source = relative / 2;
        int targetSlot = relative % 2;
        int target = targetSlot;

        if (target >= source) {
            target++;
        }

        if (source == 2 && value < 0.0) {
            ShowError("Kelvin cannot be below absolute zero.");
            return;
        }

        double celsius;

        if (source == 0) {
            celsius = value;
        } else if (source == 1) {
            celsius = (value - 32.0) * 5.0 / 9.0;
        } else {
            celsius = value - 273.15;
        }

        if (target == 0) {
            result = celsius;
        } else if (target == 1) {
            result = celsius * 9.0 / 5.0 + 32.0;
        } else {
            result = celsius + 273.15;
        }
    }

    /* AREA: square meter, square kilometer, hectare */
    else if (operation >= 30 && operation < 36) {
        const double factor[] = {
            1.0, 1000000.0, 10000.0
        };

        int relative = operation - 30;
        int source = relative / 2;
        int targetSlot = relative % 2;
        int target = targetSlot;

        if (target >= source) {
            target++;
        }

        if (value < 0.0) {
            ShowError("Area cannot be negative.");
            return;
        }

        result = value * factor[source] / factor[target];
    }

    /* VOLUME: milliliter, liter, cubic meter */
    else {
        const double factor[] = {
            0.000001, 0.001, 1.0
        };

        int relative = operation - 36;
        int source = relative / 2;
        int targetSlot = relative % 2;
        int target = targetSlot;

        if (target >= source) {
            target++;
        }

        if (value < 0.0) {
            ShowError("Volume cannot be negative.");
            return;
        }

        result = value * factor[source] / factor[target];
    }

    if (!isfinite(result)) {
        ShowError("Conversion result is outside the valid range.");
        return;
    }

    snprintf(
        output,
        sizeof(output),
        "Converted Result: %.12g",
        result
    );

    SetResultText(output);
    AddHistory(output);
}

/* ---------------------------------------------------------
   MAIN CALCULATE FUNCTION
--------------------------------------------------------- */

void Calculate(void) {
    int mode = GetSelection(categoryBox);
    int operation = GetSelection(operationBox);

    if (operation < 0) {
        ShowError("Please select an operation.");
        return;
    }

    if (mode == 0) {
        CalculateNormal(operation);
    } else if (mode == 1) {
        CalculateNumberSystem(operation);
    } else if (mode == 2) {
        CalculateMeasurement(operation);
    } else {
        ShowError("Please select a calculator type.");
    }
}

/* ---------------------------------------------------------
   UPDATE CALCULATOR MODE
--------------------------------------------------------- */

void UpdateMode(void) {
    int mode = GetSelection(categoryBox);

    if (mode == 0) {
        AddItems(
            operationBox,
            normalOperations,
            14
        );

        ShowWindow(input2, SW_SHOW);
        ShowWindow(input2Label, SW_SHOW);
    }

    else if (mode == 1) {
        AddItems(
            operationBox,
            numberOperations,
            6
        );

        ShowWindow(input2, SW_HIDE);
        ShowWindow(input2Label, SW_HIDE);
    }

    else if (mode == 2) {
        AddItems(
            operationBox,
            measurementOperations,
            42
        );

        ShowWindow(input2, SW_HIDE);
        ShowWindow(input2Label, SW_HIDE);
    }

    SetWindowTextA(input1, "");
    SetWindowTextA(input2, "");

    SetResultText("Your result will appear here.");
}

/* ---------------------------------------------------------
   WINDOW PROCEDURE
--------------------------------------------------------- */

LRESULT CALLBACK WindowProcedure(
    HWND hwnd,
    UINT message,
    WPARAM wParam,
    LPARAM lParam
) {
    switch (message) {

        case WM_CREATE: {
            HWND title;
            HWND categoryLabel;
            HWND operationLabel;
            HWND input1Label;
            HWND calculateButton;
            HWND historyTitle;
            HWND clearButton;

            title = CreateWindowA(
                "STATIC",
                "ALL-IN-ONE CALCULATOR",
                WS_CHILD | WS_VISIBLE | SS_CENTER,
                20, 20, 1000, 45,
                hwnd,
                NULL,
                NULL,
                NULL
            );

            SendMessageA(
                title,
                WM_SETFONT,
                (WPARAM)titleFont,
                TRUE
            );

            categoryLabel = CreateWindowA(
                "STATIC",
                "Calculator Type",
                WS_CHILD | WS_VISIBLE,
                40, 95, 250, 25,
                hwnd, NULL, NULL, NULL
            );

            categoryBox = CreateWindowExA(
                WS_EX_CLIENTEDGE,
                "COMBOBOX",
                "",
                WS_CHILD | WS_VISIBLE |
                CBS_DROPDOWNLIST | WS_VSCROLL,
                40, 125, 570, 250,
                hwnd,
                (HMENU)(INT_PTR)ID_CATEGORY,
                NULL,
                NULL
            );

            operationLabel = CreateWindowA(
                "STATIC",
                "Select Operation",
                WS_CHILD | WS_VISIBLE,
                40, 180, 250, 25,
                hwnd, NULL, NULL, NULL
            );

            operationBox = CreateWindowExA(
                WS_EX_CLIENTEDGE,
                "COMBOBOX",
                "",
                WS_CHILD | WS_VISIBLE |
                CBS_DROPDOWNLIST | WS_VSCROLL,
                40, 210, 570, 250,
                hwnd,
                (HMENU)(INT_PTR)ID_OPERATION,
                NULL,
                NULL
            );

            input1Label = CreateWindowA(
                "STATIC",
                "First Value",
                WS_CHILD | WS_VISIBLE,
                40, 270, 250, 25,
                hwnd, NULL, NULL, NULL
            );

            input1 = CreateWindowExA(
                WS_EX_CLIENTEDGE,
                "EDIT",
                "",
                WS_CHILD | WS_VISIBLE |
                ES_AUTOHSCROLL,
                40, 300, 570, 35,
                hwnd,
                (HMENU)(INT_PTR)ID_INPUT1,
                NULL,
                NULL
            );

            input2Label = CreateWindowA(
                "STATIC",
                "Second Value (if required)",
                WS_CHILD | WS_VISIBLE,
                40, 355, 300, 25,
                hwnd, NULL, NULL, NULL
            );

            input2 = CreateWindowExA(
                WS_EX_CLIENTEDGE,
                "EDIT",
                "",
                WS_CHILD | WS_VISIBLE |
                ES_AUTOHSCROLL,
                40, 385, 570, 35,
                hwnd,
                (HMENU)(INT_PTR)ID_INPUT2,
                NULL,
                NULL
            );

            calculateButton = CreateWindowA(
                "BUTTON",
                "CALCULATE",
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                40, 445, 570, 45,
                hwnd,
                (HMENU)(INT_PTR)ID_CALCULATE,
                NULL,
                NULL
            );

            resultLabel = CreateWindowA(
                "STATIC",
                "Your result will appear here.",
                WS_CHILD | WS_VISIBLE |
                SS_LEFT | SS_CENTERIMAGE,
                40, 510, 570, 65,
                hwnd,
                (HMENU)(INT_PTR)ID_RESULT,
                NULL,
                NULL
            );

            historyTitle = CreateWindowA(
                "STATIC",
                "CALCULATION HISTORY",
                WS_CHILD | WS_VISIBLE | SS_CENTER,
                660, 95, 340, 30,
                hwnd, NULL, NULL, NULL
            );

            historyList = CreateWindowExA(
                WS_EX_CLIENTEDGE,
                "LISTBOX",
                "",
                WS_CHILD | WS_VISIBLE |
                WS_VSCROLL | LBS_NOTIFY,
                660, 135, 340, 355,
                hwnd,
                (HMENU)(INT_PTR)ID_HISTORY,
                NULL,
                NULL
            );

            clearButton = CreateWindowA(
                "BUTTON",
                "CLEAR HISTORY",
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                660, 510, 340, 45,
                hwnd,
                (HMENU)(INT_PTR)ID_CLEAR_HISTORY,
                NULL,
                NULL
            );

            /* Apply fonts to controls */
            HWND controls[] = {
                categoryLabel,
                categoryBox,
                operationLabel,
                operationBox,
                input1Label,
                input1,
                input2Label,
                input2,
                calculateButton,
                resultLabel,
                historyTitle,
                historyList,
                clearButton
            };

            int i;

            for (i = 0; i < 13; i++) {
                SendMessageA(
                    controls[i],
                    WM_SETFONT,
                    (WPARAM)appFont,
                    TRUE
                );
            }

            /* Category list */
            const char *categories[] = {
                "Normal / Scientific Calculator",
                "Number System Calculator",
                "Measurement Calculator"
            };

            AddItems(categoryBox, categories, 3);

            UpdateMode();
            LoadHistory();

            return 0;
        }

        case WM_COMMAND: {
            int id = LOWORD(wParam);
            int event = HIWORD(wParam);

            if (id == ID_CATEGORY && event == CBN_SELCHANGE) {
                UpdateMode();
                return 0;
            }

            if (id == ID_OPERATION && event == CBN_SELCHANGE) {
                SetResultText("Enter your value and press CALCULATE.");
                return 0;
            }

            if (id == ID_CALCULATE && event == BN_CLICKED) {
                Calculate();
                return 0;
            }

            if (id == ID_CLEAR_HISTORY && event == BN_CLICKED) {
                ClearHistory();

                MessageBoxA(
                    hwnd,
                    "Calculation history cleared!",
                    "History",
                    MB_OK | MB_ICONINFORMATION
                );

                return 0;
            }

            return 0;
        }

        case WM_CTLCOLORSTATIC: {
            HDC hdc = (HDC)wParam;
            HWND control = (HWND)lParam;

            SetTextColor(hdc, textColor);

            if (control == resultLabel) {
                SetBkColor(hdc, RGB(15, 65, 75));
                return (LRESULT)resultBrush;
            }

            SetBkColor(hdc, RGB(18, 27, 45));
            return (LRESULT)backgroundBrush;
        }

        case WM_CTLCOLOREDIT:
        case WM_CTLCOLORLISTBOX: {
            HDC hdc = (HDC)wParam;

            SetTextColor(hdc, textColor);
            SetBkColor(hdc, RGB(35, 48, 68));

            return (LRESULT)inputBrush;
        }

        case WM_DESTROY:
            if (appFont) DeleteObject(appFont);
            if (titleFont) DeleteObject(titleFont);

            if (backgroundBrush) DeleteObject(backgroundBrush);
            if (inputBrush) DeleteObject(inputBrush);
            if (resultBrush) DeleteObject(resultBrush);

            PostQuitMessage(0);
            return 0;
    }

    return DefWindowProcA(
        hwnd,
        message,
        wParam,
        lParam
    );
}

/* ---------------------------------------------------------
   WINDOWS APPLICATION ENTRY POINT
--------------------------------------------------------- */

int WINAPI WinMain(
    HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPSTR lpCmdLine,
    int nCmdShow
) {
    (void)hPrevInstance;
    (void)lpCmdLine;

    WNDCLASSA wc = {0};

    wc.lpfnWndProc = WindowProcedure;
    wc.hInstance = hInstance;
    wc.lpszClassName = "AllInOneCalculatorWindow";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);

    backgroundBrush = CreateSolidBrush(
        RGB(18, 27, 45)
    );

    inputBrush = CreateSolidBrush(
        RGB(35, 48, 68)
    );

    resultBrush = CreateSolidBrush(
        RGB(15, 65, 75)
    );

    wc.hbrBackground = backgroundBrush;

appFont = CreateFontA(
    19, 0, 0, 0,
    FW_NORMAL,
    FALSE, FALSE, FALSE,
    DEFAULT_CHARSET,
    OUT_DEFAULT_PRECIS,
    CLIP_DEFAULT_PRECIS,
    CLEARTYPE_QUALITY,
    DEFAULT_PITCH | FF_DONTCARE,
    "Segoe UI"
);

    titleFont = CreateFontA(
    30, 0, 0, 0,
    FW_BOLD,
    FALSE, FALSE, FALSE,
    DEFAULT_CHARSET,
    OUT_DEFAULT_PRECIS,
    CLIP_DEFAULT_PRECIS,
    CLEARTYPE_QUALITY,
    DEFAULT_PITCH | FF_DONTCARE,
    "Segoe UI"
);

    if (!RegisterClassA(&wc)) {
        MessageBoxA(
            NULL,
            "Window registration failed.",
            "Error",
            MB_OK | MB_ICONERROR
        );
        return 1;
    }

    InitHistoryPath();

    HWND hwnd = CreateWindowExA(
        0,
        "AllInOneCalculatorWindow",
        "All-in-One Calculator",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        APP_WIDTH,
        APP_HEIGHT,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    if (hwnd == NULL) {
        MessageBoxA(
            NULL,
            "Application window could not be created.",
            "Error",
            MB_OK | MB_ICONERROR
        );

        return 1;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG message;

    while (GetMessageA(&message, NULL, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageA(&message);
    }

    return (int)message.wParam;
}
